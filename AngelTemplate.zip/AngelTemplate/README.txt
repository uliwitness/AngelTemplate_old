ANGELTEMPLATE

AngelTemplate is a generic viewer application for binary file types. The basic idea is the same as with ResEdit's and Resorcerer's 'TMPL' resources. Just that this is only for files' data forks and is implemented with property lists and other fancy Mac OS X doodads.

Note that this is a development preview. It is not yet finished, but may already be useful. I'd love to hear your feedback, suggestions etc.

CONTACT ME AT:
Uli Kusterer
http://www.zathras.de

witness (dot) of (dot) teachtext (at) gmx (dot) net
kusterer (at) gmail (dot) com
witness (at) zathras (dot) de

(c) 2006, all rights reserved.