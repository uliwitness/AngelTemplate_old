//
//  UKScrollDocumentView.h
//  UKProgressPanel
//
//  Created by Uli Kusterer on 22.10.04.
//  Copyright 2004 M. Uli Kusterer. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface UKScrollDocumentView : NSView
{

}

@end
